from django.urls import path
from . import views, api_views

urlpatterns = [
    path('', views.dashboard, name="dashboard"),
    path('patient_list/', views.patient_list, name="patient_list"),
    path('appointment_list/', views.appointment_list, name="appointment_list"),
    path("doctor_list/", views.doctor_list, name="doctor_list"),
     path('billing_list/', views.billing_list, name='billing_list'),

    # API Endpoints
    path('api/patients/', api_views.PatientListAPI.as_view()),
    path('api/appointments/', api_views.AppointmentListAPI.as_view()),
]
