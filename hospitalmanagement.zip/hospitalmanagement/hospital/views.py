from django.shortcuts import render

# Create your views here.

from .models import Patient, Appointment

def dashboard(request):
    total_patients = Patient.objects.count()
    total_appointments = Appointment.objects.count()
    return render(request, 'hospital/dashboard.html', {
        'patients': total_patients,
        'appointments': total_appointments
    })

def patient_list(request):
    patients = Patient.objects.all()
    return render(request, 'hospital/patient_list.html', {'patients': patients})

def appointment_list(request):
    appointments = Appointment.objects.all()
    return render(request, 'hospital/appointment_list.html', {'appointments': appointments})

from django.shortcuts import render
from .models import Doctor

def doctor_list(request):
    doctors = Doctor.objects.all()
    return render(request, 'hospital/doctors_list.html', {'doctors': doctors})

from django.shortcuts import render
from .models import Billing

def billing_list(request):
    bills = Billing.objects.all()   # get all billing records
    return render(request, 'hospital/billing_list.html', {'bills': bills})